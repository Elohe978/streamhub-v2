from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_health():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"

def test_catalogue():
    response = client.get("/api/v1/content")
    assert response.status_code == 200
    assert len(response.json()) >= 1

def test_search():
    response = client.get("/api/v1/search", params={"q": "Adventure"})
    assert response.status_code == 200
    assert response.json()["total"] == 1
