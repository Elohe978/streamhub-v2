package com.streamhub

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import com.streamhub.data.ApiClient
import com.streamhub.data.ContentItem
import com.streamhub.ui.StreamHubTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            StreamHubTheme {
                StreamHubApp()
            }
        }
    }
}

@Composable
fun StreamHubApp() {
    var items by remember { mutableStateOf<List<ContentItem>>(emptyList()) }
    var query by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<ContentItem?>(null) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        try { items = ApiClient.service.content() }
        catch (e: Exception) { error = "Could not reach the backend. Check BASE_URL and server status." }
    }

    MaterialTheme(colorScheme = darkColorScheme()) {
        Scaffold { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(18.dp)) {
                Text("STREAMHUB", style = MaterialTheme.typography.headlineMedium)
                Text("Discover your next watch", color = MaterialTheme.colorScheme.secondary)
                Spacer(Modifier.height(18.dp))
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Search movies and series") },
                    singleLine = true
                )
                Spacer(Modifier.height(12.dp))
                if (error != null) Text(error!!, color = MaterialTheme.colorScheme.error)
                if (selected != null) {
                    TextButton(onClick = { selected = null }) { Text("← Back to catalogue") }
                    Text(selected!!.title, style = MaterialTheme.typography.headlineSmall)
                    Text("${selected!!.year} • ${selected!!.media_type}")
                    Spacer(Modifier.height(8.dp))
                    Text(selected!!.overview)
                    Spacer(Modifier.height(12.dp))
                    Text("Playback is enabled when an authorized provider is configured.")
                } else {
                    val visible = items.filter {
                        it.title.contains(query, ignoreCase = true) ||
                        it.genres.any { genre -> genre.contains(query, ignoreCase = true) }
                    }
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(visible) { item ->
                            Card(Modifier.fillMaxWidth().clickable { selected = item }) {
                                Column(Modifier.padding(16.dp)) {
                                    Text(item.title, style = MaterialTheme.typography.titleLarge)
                                    Text("${item.year} • ${item.media_type}")
                                    Text(item.overview, maxLines = 3)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
