package com.streamhub.data

import com.streamhub.BuildConfig
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

data class ContentItem(
    val id: String,
    val title: String,
    val year: Int,
    val media_type: String,
    val overview: String,
    val genres: List<String> = emptyList()
)

data class SearchResponse(val results: List<ContentItem>, val total: Int)

interface StreamHubApi {
    @GET("api/v1/content")
    suspend fun content(): List<ContentItem>

    @GET("api/v1/search")
    suspend fun search(@Query("q") query: String): SearchResponse
}

object ApiClient {
    val service: StreamHubApi by lazy {
        Retrofit.Builder()
            .baseUrl(BuildConfig.BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(StreamHubApi::class.java)
    }
}
