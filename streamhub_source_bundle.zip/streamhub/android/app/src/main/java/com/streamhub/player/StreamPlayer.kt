package com.streamhub.player

import android.content.Context
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.exoplayer.ExoPlayer

enum class StreamFormat { HLS, DASH, MP4 }

fun createPlayer(
    context: Context,
    authorizedStreamUrl: String,
    format: StreamFormat
): ExoPlayer {
    val mime = when (format) {
        StreamFormat.HLS -> MimeTypes.APPLICATION_M3U8
        StreamFormat.DASH -> MimeTypes.APPLICATION_MPD
        StreamFormat.MP4 -> MimeTypes.VIDEO_MP4
    }

    return ExoPlayer.Builder(context).build().apply {
        setMediaItem(
            MediaItem.Builder()
                .setUri(authorizedStreamUrl)
                .setMimeType(mime)
                .build()
        )
        prepare()
    }
}
