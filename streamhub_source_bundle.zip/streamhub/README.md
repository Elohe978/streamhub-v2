# StreamHub — Streaming Aggregation Platform

A Kotlin/Jetpack Compose Android client and Python/FastAPI backend starter.

## Included
- Android app shell with Home, Search, Details and Player screens
- Media3 playback for provider-authorized HLS, DASH and MP4 URLs
- FastAPI backend with health, catalogue, search, detail and playback-session endpoints
- Provider adapter interface and configurable example provider
- PostgreSQL/Redis Docker Compose infrastructure
- Environment-based configuration and basic tests

## Important
This is a runnable development foundation, not a finished commercial streaming service.
You must integrate providers for which you have permission and valid API credentials.
The backend intentionally does not scrape, bypass DRM, defeat access controls, or extract
unauthorized streams. No copyrighted movies are bundled.

## Backend quick start
```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload
```
Open http://127.0.0.1:8000/docs

The initial catalogue is sample metadata held in memory so the API can be explored
immediately. PostgreSQL and Redis are provisioned in `docker-compose.yml`; persistence,
migrations and production authentication are the next implementation stage.

## Infrastructure
```bash
docker compose up -d
```

## Android
Open `android/` in Android Studio, allow Gradle sync, then run the `app` configuration.
Set `BASE_URL` in `app/build.gradle.kts` for your backend. For Android emulator use
`http://10.0.2.2:8000/`; for a physical phone use your reachable HTTPS backend URL.

## Playback provider
Set `DEMO_HLS_URL` in backend `.env` to a test stream you own or are authorized to use.
The example provider only returns a URL when configured. The Android player accepts HLS,
DASH and MP4 MIME types supplied by the backend.

## Production checklist
- Implement PostgreSQL repositories and Alembic migrations.
- Add OAuth/JWT authentication, authorization and rate limiting.
- Integrate documented/licensed provider APIs.
- Validate content identity and playback entitlements server-side.
- Use short-lived provider playback sessions and signed URLs where supported.
- Add Redis session storage, observability, backups and deployment secrets.
- Add privacy policy, terms, content licensing and takedown process.
